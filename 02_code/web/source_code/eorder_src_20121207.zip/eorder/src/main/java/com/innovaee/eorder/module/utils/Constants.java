package com.innovaee.eorder.module.utils;

public class Constants {

    public static String REGEX = ",";
}
