package com.innovaee.eorder.module.utils;

public class Constants {

	public static String REGEX = ",";

	/**
	 * 默认角色：普通用户
	 */
	public static Integer DEFAULT_ROLE = 2;

	/**
	 * 默认等级：普通会员
	 */
	public static Integer DEFAULT_LEVEL = 1;
}
