package com.innovaee.eorder.module.service;

public abstract class BaseService {

}
